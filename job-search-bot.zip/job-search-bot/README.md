# Job Search Bot

Личный Telegram-бот для автопоиска удалённых вакансий под резюме:
управленческое направление (основной фокус) + IT-фриланс (второстепенное).

## Установка

```bash
pip install -r requirements.txt --break-system-packages
playwright install chromium --with-deps
```

## Настройка

1. Скопируй `.env.example` в `.env`
2. Заполни все переменные (см. список ниже)
3. Создай PostgreSQL базу данных: `createdb job_search_bot`
4. Запусти: `python -m bot.main`

## Полный список переменных окружения (.env)

| Переменная | Обязательна | Описание |
|---|---|---|
| `BOT_TOKEN` | да | Токен бота от @BotFather |
| `TARGET_CHAT_ID` | да | ID чата/группы, куда бот шлёт вакансии |
| `MANAGEMENT_TOPIC_ID` | да | ID топика для управленческих вакансий |
| `IT_TOPIC_ID` | да | ID топика для IT-фриланс вакансий |
| `DB_HOST` | нет (localhost) | Хост PostgreSQL |
| `DB_PORT` | нет (5432) | Порт PostgreSQL |
| `DB_NAME` | нет (job_search_bot) | Имя базы данных |
| `DB_USER` | нет (postgres) | Пользователь БД |
| `DB_PASSWORD` | да | Пароль БД |
| `TELEGRAM_API_ID` | да | API ID с my.telegram.org (для чтения канала) |
| `TELEGRAM_API_HASH` | да | API Hash с my.telegram.org |
| `TELEGRAM_PHONE` | да | Твой номер телефона для Telegram User API |
| `FREELANCE_CHANNEL` | нет (freelansim_ru) | Канал для мониторинга IT-фриланс заказов |
| `MIN_SALARY` | нет (100000) | Минимальная ЗП для фильтра |
| `CHECK_INTERVAL_MINUTES` | нет (10) | Как часто парсить (минуты) |
| `TRUDVSEM_API_URL` | нет (готовый URL) | URL API trudvsem.ru |
| `PROXY_URL` | нет | Прокси для HH.ru/Rabota.ru парсеров, если понадобится |
| `RESUME_PATH` | нет | Путь к резюме (для будущего расширения скоринга) |

## Как получить ID топиков в группе с форумом

1. Включи "Темы" (Topics) в настройках группы
2. Создай два топика: "Управление" и "IT"
3. Отправь любое сообщение в топик и перешли его боту @getidsbot — он покажет `message_thread_id`

## Важно про источники

- **trudvsem.ru** — официальное открытое API, самый надёжный источник
- **Habr Career** — HTML-парсинг, селекторы могут потребовать обновления при смене вёрстки
- **HH.ru / Rabota.ru** — работают через Playwright БЕЗ авторизации (публичный API HH.ru закрыт с апреля 2026).
  Это самые хрупкие источники: возможны капчи, блокировки IP, изменение вёрстки.
  Перед первым запуском сверь селекторы в `parsers/hh_parser.py` и `parsers/rabota_parser.py`
  с актуальной разметкой сайтов через DevTools браузера.
- **Telegram-канал** — через Telethon, официальный Telegram API, самый стабильный из "серых" источников

## Структура проекта

```
job-search-bot/
├── bot/main.py              # точка входа: бот + планировщик
├── config.py                 # загрузка переменных окружения
├── db/
│   ├── schema.sql             # схема таблицы vacancies
│   └── storage.py             # работа с PostgreSQL
├── filters/
│   └── vacancy_filter.py      # удалёнка, стоп-слова по заголовку, ЗП, скоринг
├── parsers/
│   ├── trudvsem_parser.py     # открытое API
│   ├── habr_parser.py         # HTML-парсинг
│   ├── hh_parser.py           # Playwright без авторизации
│   ├── rabota_parser.py       # Playwright без авторизации
│   └── telegram_parser.py     # Telethon, чтение канала
└── requirements.txt
```
